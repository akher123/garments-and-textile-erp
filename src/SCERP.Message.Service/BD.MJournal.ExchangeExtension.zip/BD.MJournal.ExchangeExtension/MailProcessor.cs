﻿using BD.MJournal.ApplicationServices;
using BD.MJournal.Data.Interfaces;
using BD.MJournal.Models;
using BD.MJournal.Utilities;
using BD.MJournal.Utilities.Constants;
using Microsoft.Exchange.WebServices.Data;
using System.Collections.Generic;
using System.Linq;

namespace BD.MJournal.ExchangeExtension
{
    public class MailProcessor
    {
        private readonly IJournalMailService _journalMailService;
        public MailProcessor(IJournalMailService journalMailService)
        {
            _journalMailService = journalMailService;
        }

        //private readonly IJournalMailRepository _journalMailRepository;
        //public MailProcessor(IJournalMailRepository journalMailRepository)
        //{
        //    _journalMailRepository = journalMailRepository;
        //}
        /// <summary>
        /// Step-7: For multi worker process.
        /// Preparing mail (that get from exchange server) for saving in DB
        /// </summary>
        /// <param name="emailMessage"></param>
        public void SaveMessage(EmailMessage emailMessage)
        {
            var messageType = emailMessage.GetType();

            var journalMail = new JournalMail();

            journalMail.IsMail = messageType.Name == MessageType.EmailMessage.ToString();
            journalMail.MessageId = emailMessage.InternetMessageId;
            journalMail.DateReceived = emailMessage.DateTimeReceived;
            journalMail.HasAttachment = emailMessage.HasAttachments;
            journalMail.Subject = emailMessage.Subject;
            journalMail.MessageBody = emailMessage.Body;
            journalMail.Size = emailMessage.Size;

            var contactInfos = new List<ContactInfo>();

            contactInfos.Add(new ContactInfo { Email = emailMessage.From.Address, Name = emailMessage.From.Name, Type = MailConstatnt.FROM });
            contactInfos.AddRange(emailMessage.ToRecipients.Select(x => new ContactInfo { Email = x.Address, Name = x.Name, Type = MailConstatnt.TO }));
            contactInfos.AddRange(emailMessage.CcRecipients.Select(x => new ContactInfo { Email = x.Address, Name = x.Name, Type = MailConstatnt.CC }));
            contactInfos.AddRange(emailMessage.BccRecipients.Select(x => new ContactInfo { Email = x.Address, Name = x.Name, Type = MailConstatnt.BCC }));

            journalMail.AttatchmentNames = GetAttatchmentsName(emailMessage);

            MimeContent mimeContent = emailMessage.MimeContent;

            var mailFile = new MailFile { OutlooklFile = mimeContent.Content, JournalMail = journalMail };

            _journalMailService.Save(journalMail, mailFile, contactInfos);
            //_journalMailRepository.Save(journalMail, mailFile, contactInfos);

            
        }

        private string GetAttatchmentsName(EmailMessage emailMessage)
        {
            var name = string.Empty;
            if (emailMessage.Attachments != null && emailMessage.Attachments.Any())
            {
                return emailMessage.Attachments.Aggregate(name, (current, attachment) => current + (attachment.Name + ", "));
            }
            return name;
        }

        private void GetJournalMailContacts(List<JournalMailContact> journalMailContact, EmailAddressCollection emailAddressList, string contactType)
        {
            foreach(var item in emailAddressList)
            {
                journalMailContact.Add(new JournalMailContact { Contact = new BD.MJournal.Models.Contact { Name = item.Name, EmailAddress = item.Address }, ContactType = contactType });
            }
        }

        private void GetJournalMailContact(List<JournalMailContact> journalMailContact, EmailAddress emailAddress, string contactType)
        {
            journalMailContact.Add(new BD.MJournal.Models.JournalMailContact { Contact = new BD.MJournal.Models.Contact { Name = emailAddress.Name, EmailAddress = emailAddress.Address }, ContactType = contactType });
        }
    }
}
