﻿using BD.MJournal.ApplicationServices;
using BD.MJournal.Data;
using BD.MJournal.Data.Interfaces;
using BD.MJournal.Data.Repositories;
using log4net;
using Microsoft.Exchange.WebServices.Data;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.Entity.Core;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Threading;
using System.Transactions;

namespace BD.MJournal.ExchangeExtension
{
    public class ParallelProcessor
    {
        private static readonly ILog _logger = LogManager.GetLogger(typeof(ParallelProcessor));
        IJournalMailService _journalMailService;
        //IJournalMailRepository _journalMailRepository;
        BackgroundWorker worker = new BackgroundWorker();

        private static object lockWorker = new object();

        public ExchangeService _exchangeService;
        public Item MailItem { get; set; }
        public int Id { get; set; }
        public ItemId ItemId { get; set; }
        public FolderId FailedFolderId { get; set; }

        private event EventHandler _Completed;
        public event EventHandler Completed
        {
            add { _Completed += value; }
            remove { _Completed -= value; }
        }

        private event ProgressChangedEventHandler _ProgressChanged;
        public event ProgressChangedEventHandler ProgressChanged
        {
            add { _ProgressChanged += value; }
            remove { _ProgressChanged -= value; }
        }

        public bool IsBusy { get { return worker.IsBusy; } }

        public ParallelProcessor()
        {
            worker.DoWork += worker_DoWork;
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;

            worker.WorkerSupportsCancellation = true;
            worker.WorkerReportsProgress = true;
        }

        /// <summary>
        /// Step-6: For multi worker process. 
        /// Start child process
        /// </summary>
        public void Process()
        {
            _exchangeService = Utilities.InitService();

            var Context = new MJournalContext();

            //TODO: Temp code: After implementing DI we need to remove this code.
            IJournalMailRepository journalMailRepository = new JournalMailRepository(Context);
            IContactRepository contactRepository = new ContactRepository(Context);
            IDomainRepository domainRepository = new DomainRepository(Context);
            IMailFileRepository mailFileRepository = new MailFileRepository(Context);
            IJournalMailContactRepository journalMailContactRepository = new JournalMailContactRepository(Context);

            _journalMailService = new JournalMailService(journalMailRepository, contactRepository, domainRepository, mailFileRepository, journalMailContactRepository);

            //MJournalContext context = new MJournalContext();
            //_journalMailRepository = new JournalMailRepository(context);

            worker.RunWorkerAsync();
        }
        /// <summary>
        /// Step-7: For multi worker process.
        /// STart bachground work process by child
        /// Mail only move in 'Failed' folder if there is ServiceObjectPropertyException and any core expection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                _logger.Info(string.Format("Process No => {0}, Thread No => {1}", Id, Thread.CurrentThread.ManagedThreadId));

                EmailMessage emailMessage = null;
                lock (lockWorker)
                {
                    emailMessage = EmailMessage.Bind(_exchangeService, new ItemId(MailItem.Id.UniqueId), new PropertySet(BasePropertySet.IdOnly, ItemSchema.Attachments));
                }  
                //emailMessage.IsRead = true;
                //emailMessage.Update(ConflictResolutionMode.AlwaysOverwrite);

                if (emailMessage.Attachments.Count > 0)
                {
                    // Iterate through the attachments collection and load each attachment.
                    foreach (Attachment attachment in emailMessage.Attachments)
                    {
                        // Load attachment into memory and write out the subject.
                        var itemAttachment = attachment as ItemAttachment;

                        lock (lockWorker)
                        {
                            itemAttachment.Load(new PropertySet(EmailMessageSchema.MimeContent));
                        }
                        var message = (EmailMessage)itemAttachment.Item;

                        try
                        {
                            var dateTimeReceived = message.DateTimeReceived;

                            if (dateTimeReceived != null && !_journalMailService.IsExist(message.InternetMessageId)) // If mail is not existes in DB
                            //if (dateTimeReceived != null && !_journalMailRepository.IsExist(message.InternetMessageId)) // If mail is not existes in DB
                            {
                                new MailProcessor(_journalMailService).SaveMessage(message); // Start saving mail in DB
                                //new MailProcessor(_journalMailRepository).SaveMessage(message); // Start saving mail in DB
                                MailItem.Move(WellKnownFolderName.DeletedItems);
                            }
                            else
                            {
                                MailItem.Move(WellKnownFolderName.DeletedItems);
                            }
                        }
                        
                        catch (SqlException ex)
                        {
                            _logger.Error("SQL exception \n", ex);
                        }
                        catch (DbUpdateException ex)
                        {
                            _logger.Error(string.Format("Probably for duplicate key. Mail Id => {0}", message.InternetMessageId.ToString()), ex);
                        }
                        catch (EntitySqlException ex)
                        {
                            _logger.Error("Entity SQL exception \n", ex);
                        }
                        catch (ServiceObjectPropertyException ex)
                        {
                            MailItem.Move(FailedFolderId);
                        }
                        catch (ServiceRequestException ex)
                        {
                            _logger.Error("Service Request exception on db \n", ex);
                            _exchangeService = Utilities.InitService();
                        }
                        catch (ServiceResponseException ex)
                        {
                            _logger.Error("Service Response exception on db \n", ex);
                            _exchangeService = Utilities.InitService();
                        }
                        catch (TransactionAbortedException ex)
                        {
                            _logger.Error("Transaction exception \n", ex);
                        }
                        catch (Exception ex)
                        {
                            _logger.Error("From DB Exception \n", ex);
                            _logger.Error(ex);
                            MailItem.Move(FailedFolderId);
                        }
                    }
                }
                else
                {
                    MailItem.Move(WellKnownFolderName.DeletedItems);
                }
            }
            catch (ServiceObjectPropertyException ex)
            {
                MailItem.Move(FailedFolderId);
            }
            catch (ServiceRequestException ex)
            {
                _logger.Error("Service Request exception on service \n", ex);
                _exchangeService = Utilities.InitService();
            }
            catch (ServiceResponseException ex)
            {
                _logger.Error("Service Response exception on service\n", ex);
                if (ex.ErrorCode== Microsoft.Exchange.WebServices.Data.ServiceError.ErrorMimeContentConversionFailed)
                {
                    MailItem.Move(FailedFolderId);
                }

                _exchangeService = Utilities.InitService();
            }
            catch (Exception ex)
            {
                _logger.Error("From Service Exception", ex);
                MailItem.Move(FailedFolderId);
            }
        }
        /// <summary>
        /// Step-9: For multi worker process
        /// After completing the DAL operation back to this event
        /// After task is completed, It send to TaskCompleted event in Excahnage manager
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (_Completed != null)
            {
                _Completed(this, new EventArgs());
            }
        }
    }
}
