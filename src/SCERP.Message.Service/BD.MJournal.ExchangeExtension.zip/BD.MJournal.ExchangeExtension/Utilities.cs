﻿using BD.MJournal.Utilities;
using Microsoft.Exchange.WebServices.Data;
using System;
using System.Net;
using System.Net.Security;

namespace BD.MJournal.ExchangeExtension
{
    public class Utilities
    {
        public static NetworkCredential GetNetworkCredential()
        {
            return new NetworkCredential(WebConfig.ExchangeUser, WebConfig.ExchangeUserPass, WebConfig.ExchangeServerDomain);
        }
        public static Uri GetExchangeWebServiceUrl()
        {
            return new Uri(WebConfig.ExchangeServer);
        }

        public static ExchangeService InitService()
        {
            ExchangeService exchangeService = new ExchangeService(ExchangeVersion.Exchange2007_SP1) { Url = Utilities.GetExchangeWebServiceUrl(), Credentials = Utilities.GetNetworkCredential() };
            ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate { return true; });
            exchangeService.KeepAlive = true;
            exchangeService.Timeout = WebConfig.ExchangeServiceTimeOut;

            return exchangeService;
        }
    }
}
