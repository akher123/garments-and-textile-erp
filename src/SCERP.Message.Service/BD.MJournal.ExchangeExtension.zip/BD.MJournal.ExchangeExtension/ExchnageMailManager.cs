﻿using BD.MJournal.Utilities;
using log4net;
using Microsoft.Exchange.WebServices.Data;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;

// This is the main process
namespace BD.MJournal.ExchangeExtension
{
    public class ExchnageMailManager
    {
        private static readonly ILog _logger = LogManager.GetLogger(typeof(ExchnageMailManager));
        private ExchangeService exchangeService;
        private List<ParallelProcessor> processors = null;
        private readonly FolderId _failedFolderId;
        private ConcurrentQueue<Item> ItemQueue;
        private static object _LockObject = new object();
        bool processing = false;
        bool downloadStarted = false;
        public ExchnageMailManager()
        {
            exchangeService = Utilities.InitService();

            ItemQueue = new ConcurrentQueue<Item>();
            _failedFolderId = GetfFolderId(exchangeService, FolderName.Failed);
        }

        /// <summary>
        /// Step-2: For multi worker process. Initiate all child process
        /// </summary>
        public void ProcessMail()
        {
            processors = Enumerable.Range(1, WebConfig.NoOfBackgroundWorker).Select(x => new ParallelProcessor() { Id = x, FailedFolderId = _failedFolderId}).ToList();
            processors.ForEach(x => { x.Completed += TaskCompleted; x.ProgressChanged += TaskProgressChanged; });

            var taskManageQueue = new System.Threading.Tasks.Task(() => ManageQueue());
            var taskManageProcess = new System.Threading.Tasks.Task(() => CheckProcess());

            taskManageQueue.Start();
            taskManageProcess.Start();

            System.Threading.Tasks.Task.WaitAll(taskManageQueue, taskManageProcess);
        }

        /// <summary>
        /// Step-3: For multi worker process.
        /// Parent process Start Queueing mails.
        /// Parent process Enqueue 50 mails  
        /// </summary>
        private void ManageQueue()
        {
            try
            {
                int totalMail = Folder.Bind(exchangeService, WellKnownFolderName.Inbox).TotalCount;
                if (totalMail == 0)
                {
                    downloadStarted = true;
                    return;
                }

                SearchFilter unreadFilter = new SearchFilter.SearchFilterCollection(LogicalOperator.And, new SearchFilter.IsEqualTo(EmailMessageSchema.IsRead, false));

                for (var i = 0; i < totalMail; i += 50)
                {
                    FindItemsResults<Item> findInboxMails = exchangeService.FindItems(WellKnownFolderName.Inbox, unreadFilter, new ItemView(50, i));
                    if (findInboxMails.Items.Count == 0)
                    {
                        downloadStarted = true;
                    }
                    foreach (Item item in findInboxMails.Items)
                    {
                        Enqueue(item);
                    }
                }
            }
            catch (ServiceResponseException ex)
            {
                _logger.Error("Service Initialize \n", ex);
                exchangeService = Utilities.InitService(); //If there is any exception then service is initiated and start ManageQueue
                ManageQueue();
            }
            catch (Exception ex)
            {
                _logger.Error("Queue Exception \n", ex);
                downloadStarted = true;
                ManageQueue();
            }
        }

        /// <summary>
        /// Step-4: For multi worker process
        /// From Parent process enqueue mail and send to child process 
        /// </summary>
        /// <param name="item"></param>
        private void Enqueue(Item item)
        {
            if (!IsExistInQueue(item.Id))
            {
                ItemQueue.Enqueue(item);
            }

            ManageProcess();
        }
        /// <summary>
        /// This check only for active parent process
        /// </summary>
        private void CheckProcess()
        {

            //The service will be active IF
            //1) Item in Queue
            //2) Downloadis ongoing
            //3) Child process is running
            while (ItemQueue.Count > 0 || !downloadStarted || processors.Any(x=> x.IsBusy)) 
            {
                Thread.Sleep(500);           
                _logger.Info(string.Format("Queue Size => {0}, Process Downloading => {1}, No of Process Working => {2}", ItemQueue.Count, downloadStarted, processors.Count(x=> x.IsBusy)));
                if(ItemQueue.Count > 0 && processors.All(x=> !x.IsBusy))
                {
                    ManageProcess();
                }
            }
        }

        /// <summary>
        /// Step-5:For multi worker process
        /// Dequeue and Start child process
        /// </summary>
        private void ManageProcess()
        {
            if (processing)
            {
                return;
            }
            downloadStarted = true;
            while ((processing = ItemQueue.Count > 0))
            {
                try
                {
                    var processor = processors.FirstOrDefault(x => !x.IsBusy);
                    if (processor == null) //If all child process is busy
                    {
                        Thread.Sleep(1000);
                        continue;
                    }

                    lock (_LockObject)
                    {
                        Item item;
                        ItemQueue.TryDequeue(out item);

                        processor.MailItem = item;
                        processor.ItemId = item.Id;
                    }
                    processor.Process(); //STart child process
                }
                catch(Exception ex)
                {
                    _logger.Error("Error In ManageProcess \n", ex);
                }
            }
        }
        /// <summary>
        /// Step-10: For multi worker process
        /// Back to main process from child process after completing one operation by child
        /// If there is item in Queue then 'ManageProcess' will continue otherwise 'ManageQueue' will call
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void TaskCompleted(object sender, EventArgs e)
        {
            var processor = (ParallelProcessor)sender;

            //processors.RemoveAll(x => x.Id == processor.Id);
            ////When a child process is completed then remove it from Process collection and add it again.
            ////Because we need to initiate the DBcontex everytime

            //processor = new ParallelProcessor() { Id = processor.Id, FailedFolderId = _failedFolderId };
            //processor.Completed += TaskCompleted;
            //processor.ProgressChanged += TaskProgressChanged;

            //processors.Add(processor);
            if (ItemQueue.Count == 0)
            {
                ManageQueue();
            }
        }

        public void TaskProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            var processor = (ParallelProcessor)sender;
        }

        public FolderId GetfFolderId(ExchangeService exchangeService, FolderName folderName)
        {
            try
            {
                Folder rootfolder = Folder.Bind(exchangeService, WellKnownFolderName.MsgFolderRoot);
                rootfolder.Load();

                Folder folder;

                var folderCount = rootfolder.ChildFolderCount;

                if (folderCount > 1)
                {
                    folder = rootfolder.FindFolders(new FolderView(folderCount))
                        .FirstOrDefault(x => x.DisplayName.Equals(folderName.ToString(), StringComparison.OrdinalIgnoreCase));

                    if (folder != null)
                    {
                        return folder.Id;
                    }
                }

                folder = new Folder(exchangeService);
                folder.DisplayName = folderName.ToString();
                folder.Save(WellKnownFolderName.MsgFolderRoot);

                return folder.Id;
            }
            catch (Exception ex)
            {
                _logger.Error(ex);
                throw ex;
            }
        }

        public enum FolderName
        {
            Failed
        }

        private bool IsExistInQueue(ItemId id)
        {
            try
            {
                return ItemQueue.Any(i => i.Id.Equals(id)) && processors.Any(x=> x.IsBusy && x.ItemId.Equals(id) );
            }
            catch(Exception ex)
            {
                _logger.Error("Check Item in Queue \n", ex);
                return true;
            }
        }
    }
}
